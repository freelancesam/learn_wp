<?php
require_once('get_wp.php');

echo do_shortcode('[videogallery id="'.$_GET['id'].'"]');