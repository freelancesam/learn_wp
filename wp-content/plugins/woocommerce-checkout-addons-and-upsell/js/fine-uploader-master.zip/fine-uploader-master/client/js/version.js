/*global qq */
qq.version="5.0.8";
